import { createGameMenu } from "./gameMenu.js";

const cardsApp = () => {
    createGameMenu();
}

cardsApp();